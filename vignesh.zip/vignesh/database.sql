-- MySQL Workbench SQL script for the registration database
CREATE DATABASE IF NOT EXISTS user_registration CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE user_registration;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(30),
  address VARCHAR(255),
  gender ENUM('Male','Female','Other') DEFAULT 'Other',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
