<?php
require_once 'config.php';
$message = '';
$messageClass = '';

if (isset($_GET['registered'])) {
    $message = 'Registration successful. Please log in below.';
    $messageClass = 'alert-success';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $message = 'Please enter both email and password.';
        $messageClass = 'alert-danger';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter a valid email address.';
        $messageClass = 'alert-danger';
    } else {
        $stmt = $conn->prepare('SELECT id, full_name, password FROM users WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 0) {
            $message = 'No account found with that email.';
            $messageClass = 'alert-danger';
        } else {
            $stmt->bind_result($id, $full_name, $passwordHash);
            $stmt->fetch();

            if (password_verify($password, $passwordHash)) {
                $message = 'Login successful. Welcome back, ' . htmlspecialchars($full_name) . '!';
                $messageClass = 'alert-success';
            } else {
                $message = 'Incorrect password. Please try again.';
                $messageClass = 'alert-danger';
            }
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH6egcV3zphUcdMjoI8u0jP+7fLxy2AW+U+6R1XQs7VxI8o+Ic9lHqlcWepJg6ba" crossorigin="anonymous" />
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title mb-4">Login</h2>
                        <?php if ($message): ?>
                            <div class="alert <?= $messageClass ?: 'alert-info' ?>" role="alert">
                                <?= htmlspecialchars($message) ?>
                            </div>
                        <?php endif; ?>
                        <form action="login.php" method="post" class="row g-3">
                            <div class="col-12">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="email" name="email" required />
                            </div>
                            <div class="col-12">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required />
                            </div>
                            <div class="col-12 d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">Login</button>
                            </div>
                            <div class="col-12 text-center">
                                <a href="registerform.html">Need an account? Register</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
