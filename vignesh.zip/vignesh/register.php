<?php
require_once 'config.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $gender = $_POST['gender'] ?? 'Other';

    if (!$full_name || !$email || !$password || !$confirm_password) {
        $message = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter a valid email address.';
    } elseif ($password !== $confirm_password) {
        $message = 'Passwords do not match.';
    } else {
        $stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = 'This email is already registered.';
            $stmt->close();
        } else {
            $stmt->close();
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $insert = $conn->prepare('INSERT INTO users (full_name, email, password, phone, address, gender) VALUES (?, ?, ?, ?, ?, ?)');
            $insert->bind_param('ssssss', $full_name, $email, $password_hash, $phone, $address, $gender);

            if ($insert->execute()) {
                $insert->close();
                header('Location: login.php?registered=1');
                exit;
            } else {
                $message = 'Error saving your data. Please try again later.';
            }
            $insert->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register Result</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH6egcV3zphUcdMjoI8u0jP+7fLxy2AW+U+6R1XQs7VxI8o+Ic9lHqlcWepJg6ba" crossorigin="anonymous" />
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title mb-4">Registration Status</h2>
                        <div class="alert <?= strpos($message, 'successful') !== false ? 'alert-success' : 'alert-danger' ?>" role="alert">
                            <?= htmlspecialchars($message) ?>
                        </div>
                        <a href="registerform.html" class="btn btn-primary">Back to Registration</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
